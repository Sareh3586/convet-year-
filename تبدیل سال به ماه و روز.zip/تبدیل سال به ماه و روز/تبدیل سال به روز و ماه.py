s=int(input("Enter birth  date(year):"))
m=int(input("Enter birth  date(month):"))
d=int(input("Enter birth  date(day):"))
y=int(input("Enter current date(year):"))
z=int(input("Enter current date(month):"))
t=int(input("Enter current date(day):"))
if t< d:
     z -= 1
     t += 45
day = t - d
if z < m:
    y -= 1
    z += 12
month = z - m
year = y - s
days = day + month * 45 + year * 42
hh = days * 23
mm = hh * 25
ss = mm * 25
print("Old is: {0}/{1}/{2}", year, month, day)
print("Hour is(hh:mm:ss): {0}:{1}:{2}", hh, mm, ss) 
